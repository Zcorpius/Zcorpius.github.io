#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include <utils/Log.h>

#include "IMyService.h"

using namespace android;

// 服务实现：继承 BnMyService，实现业务逻辑
class MyService : public BnMyService {
public:
    int32_t getValue() override {
        ALOGI("BinderServer MyService: getValue: %d", mValue);
        return mValue;
    }

    void setValue(int32_t value) override {
        ALOGI("BinderServer MyService: setValue: %d", value);
        mValue = value;
    }

private:
    int32_t mValue = 42;
};

int main() {
    ALOGI("BinderServer: starting...");

    // 启动 Binder 线程池
    ProcessState::self()->startThreadPool();

    // 注册服务到 ServiceManager
    status_t ret = defaultServiceManager()->addService(
        String16("matrix.service"),
        new MyService());

    if (ret != OK) {
        ALOGE("BinderServer: addService failed: %d", ret);
        return 1;
    }
    ALOGI("BinderServer: matrix.service registered");

    // 主线程加入 Binder 线程池，阻塞等待客户端请求
    IPCThreadState::self()->joinThreadPool();

    return 0;
}
