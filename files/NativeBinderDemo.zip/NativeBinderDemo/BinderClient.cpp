#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include <utils/Log.h>

#include "IMyService.h"

using namespace android;

int main() {
    ALOGI("BinderClient: starting...");

    // 初始化 ProcessState（打开 /dev/binder，mmap）
    ProcessState::self()->startThreadPool();

    // 从 ServiceManager 获取服务的 BpBinder 代理
    sp<IBinder> binder = defaultServiceManager()->getService(String16("matrix.service"));

    if (binder == nullptr) {
        ALOGE("BinderClient: failed to get matrix.service");
        return 1;
    }

    // BpBinder → BpMyService（通过 interface_cast / asInterface）
    sp<IMyService> service = interface_cast<IMyService>(binder);

    // 调用 getValue()：BpMyService 打包 Parcel → BpBinder::transact → IPC → 服务端
    int32_t value = service->getValue();
    ALOGI("BinderClient: getValue() = %d", value);

    // 调用 setValue(100)
    service->setValue(100);
    ALOGI("BinderClient: setValue(100)");

    // 再次获取，验证值已改变
    value = service->getValue();
    ALOGI("BinderClient: getValue() = %d", value);

    return 0;
}
