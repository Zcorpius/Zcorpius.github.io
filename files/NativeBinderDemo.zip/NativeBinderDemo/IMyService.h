#ifndef NATIVE_BINDER_DEMO_IMYSERVICE_H
#define NATIVE_BINDER_DEMO_IMYSERVICE_H

#include <binder/IInterface.h>
#include <binder/Parcel.h>

namespace android {

// 接口定义
class IMyService : public IInterface {
public:
    // DECLARE — 在类内部声明方法（只有函数签名，没有实现）
    DECLARE_META_INTERFACE(MyService)

    // 纯虚函数，没有默认实现。子类来进行实现
    virtual int32_t getValue() = 0;
    virtual void setValue(int32_t value) = 0;

    enum {
        GET_VALUE = IBinder::FIRST_CALL_TRANSACTION,
        SET_VALUE = IBinder::FIRST_CALL_TRANSACTION + 1,
    };
};

// 客户端代理：将方法调用打包成 Parcel，通过 remote()->transact() 发送给服务端
class BpMyService : public BpInterface<IMyService> {
public:
    explicit BpMyService(const sp<IBinder>& impl) : BpInterface<IMyService>(impl) {}

    int32_t getValue() override {
        Parcel data, reply;
        data.writeInterfaceToken(getInterfaceDescriptor());
        remote()->transact(GET_VALUE, data, &reply);
        return reply.readInt32();
    }

    void setValue(int32_t value) override {
        Parcel data, reply;
        data.writeInterfaceToken(getInterfaceDescriptor());
        data.writeInt32(value);
        remote()->transact(SET_VALUE, data, &reply);
    }
};

// IMPLEMENT — 在类外部实现方法（函数体）
IMPLEMENT_META_INTERFACE(MyService, "demo.IMyService");

// 服务端 Stub：接收 transact 请求，根据 code 分发到具体方法
class BnMyService : public BnInterface<IMyService> {
public:
    status_t onTransact(uint32_t code, const Parcel& data, Parcel* reply,
                        uint32_t flags) override {
        switch (code) {
            case GET_VALUE: {
                CHECK_INTERFACE(IMyService, data, reply);
                reply->writeInt32(getValue());
                return OK;
            }
            case SET_VALUE: {
                CHECK_INTERFACE(IMyService, data, reply);
                setValue(data.readInt32());
                return OK;
            }
            default:
                return BBinder::onTransact(code, data, reply, flags);
        }
    }
};

} // namespace android

#endif // NATIVE_BINDER_DEMO_IMYSERVICE_H
